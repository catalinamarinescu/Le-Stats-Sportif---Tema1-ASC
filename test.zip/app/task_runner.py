from queue import Queue
from threading import Thread, Event, Lock
import time
import os
import json
from flask import request


class ThreadPool:
    def __init__(self):
        # You must implement a ThreadPool of TaskRunners
        # Your ThreadPool should check if an environment variable TP_NUM_OF_THREADS is defined
        # If the env var is defined, that is the number of threads to be used by the thread pool
        # Otherwise, you are to use what the hardware concurrency allows
        # You are free to write your implementation as you see fit, but
        # You must NOT:
        #   * create more threads than the hardware concurrency allows
        #   * recreate threads for each task
        self.job_queue = Queue()
        if os.getenv("TP_NUM_OF_THREADS"):
            self.number_of_threads = int(os.getenv("TP_NUM_OF_THREADS"))
        else:
            self.number_of_threads = os.cpu_count()

        self.lock = Lock()    
        self.job_status = {}
        self.job_dict = {}
        self.threads = []
        self.is_shutdown = Event()
        for i in range(self.number_of_threads):
            thread = TaskRunner(i, self.job_queue, self.job_status, self.job_dict, self.is_shutdown)
            thread.start()
            self.threads.append(thread)


    def add_job(self, job, data, job_id):
        self.lock.acquire()
        self.job_queue.put((job, data, job_id))
        self.job_status[str(job_id)] = 'running'
        self.lock.release()

    def shutdown(self):
        self.is_shutdown.set()
        self.job_queue.join()
        for i in range(len(self.threads)):
            self.threads[i].join()  

class TaskRunner(Thread):
    def __init__(self, i, job_queue, job_status, job_dict, status):
        # TODO: init necessary data structures
        Thread.__init__(self)
        self.i = i
        self.job_queue = job_queue
        self.lock = Lock()
        self.job_status = job_status
        self.job_dict = job_dict
        self.status = status

    def run(self):
        
        while True:
            # TODO
            # Get pending job
            # Execute the job and save the result to disk
            # Repeat until graceful_shutdown
            self.lock.acquire()
            job, data, job_id = self.job_queue.get()
            self.lock.release()
            try:
                result = job(data)
                self.job_dict[str(job_id)] = result
                if not os.path.exists('results'):
                    os.mkdir('results')
                file_path = os.path.join(f'results/job_id_{job_id}.json')
                with open(file_path, 'w') as f:
                    f.write(json.dumps(result))

                self.job_status[str(job_id)] = "done"
            except Exception as e:
                print(f"Error processing job {job_id}: {e}")
                self.job_status[str(job_id)] = "error"
            self.job_queue.task_done()
